package com.codecanyon.bestapplock.services;


import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.codecanyon.bestapplock.R;
import com.codecanyon.bestapplock.utils.AppPreferences;
import com.codecanyon.bestapplock.utils.IconHandler;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.picasso.Picasso;

import java.util.List;

public class LockServicePattern extends Service implements View.OnClickListener,
        View.OnKeyListener {

    //Flags
    private ViewState mViewState = ViewState.HIDDEN;

    private enum ViewState {SHOWING, SHOWN, HIDING, HIDDEN}

    private ServiceState mServiceState = ServiceState.NOT_BOUND;

    private enum ServiceState {NOT_BOUND, BINDING, BOUND, UNBINDING}

    //Others
    private AppLockService mAppLockService;
    private Intent mIntent;
    private String mAction;
    private String mPackageName;
    private long mTimeViewShown;
    private String mPattern;

    //Window views
    private WindowManager.LayoutParams mLayoutParams;
    private WindowManager mWindowManager;

    //Views
    private View mRootView;
    PatternLockView mPatternLockView;
    ImageView LockAppIcon;
    TextView TxtEnterPasscode;

    Boolean vibrate = false;

    private Picasso mPicasso;

    //Actions
    private static final String CLASSNAME = LockServicePattern.class.getName();
    private static final String ACTION_HIDE = CLASSNAME + ".action.hide";
    public static final String ACTION_COMPARE = CLASSNAME + ".action.compare";
    private static final String ACTION_NOTIFY_PACKAGE_CHANGED = CLASSNAME
            + ".action.notify_package_changed";

    public static final String EXTRA_PACKAGENAME = CLASSNAME;

    private final ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName cn, IBinder binder) {


            mServiceState = ServiceState.BOUND;
        }

        @Override
        public void onServiceDisconnected(ComponentName cn) {
            mServiceState = ServiceState.UNBINDING;
        }
    };

    public static Intent getLockIntent(Context c, String packageName) {
        Intent i = new Intent(c, LockServicePattern.class);
        i.setAction(ACTION_COMPARE);
        i.putExtra(EXTRA_PACKAGENAME, packageName);
        return i;
    }

    public static void hide(Context c) {
        Intent i = new Intent(c, LockServicePattern.class);
        i.setAction(ACTION_HIDE);
        c.startService(i);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }

        if (ACTION_HIDE.equals(intent.getAction())) {
            finish(true);
            return START_NOT_STICKY;
        }

        if (ACTION_NOTIFY_PACKAGE_CHANGED.equals(intent.getAction())) {
            String newPackageName = intent.getStringExtra(EXTRA_PACKAGENAME);
            if (newPackageName == null
                    || !getPackageName().equals(newPackageName)) {
                finish(true);
                return START_NOT_STICKY;
            }
        } else {
            mIntent = intent;
            showView();
        }
        return START_NOT_STICKY;
    }


    private View inflateRootView() {
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater li = LayoutInflater.from(this);
        View root = (View) li.inflate(R.layout.activity_lock_pattern, null);


        root.setOnKeyListener(this);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);

        mPatternLockView = (PatternLockView) root.findViewById(R.id.pattern_lock_view);

        MobileAds.initialize(getApplicationContext(), getResources().getString(R.string.app_id));
        final AdView mAdView = (AdView) root.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("9C7EDF9236FE42147D1F7317080B1055").build();
        mAdView.loadAd(adRequest);
        mAdView.setVisibility(View.GONE);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

        LockAppIcon = (ImageView) root.findViewById(R.id.LockAppIcon);
        TxtEnterPasscode = (TextView) root.findViewById(R.id.TxtEnterPasscode);
        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                //PatternLockUtils.stringToPattern(mPatternLockView,mPattern);
                String CurrentPattern = PatternLockUtils.patternToString(mPatternLockView, pattern);
                if (mPattern.equalsIgnoreCase(CurrentPattern)) {
                    mAppLockService.unlockApp(mPackageName);
                    finish(true);
                } else {
                    mPatternLockView.setViewMode(PatternLockView.PatternViewMode.WRONG);
                    TxtEnterPasscode.setText("Wrong Pattern");
                }
            }

            @Override
            public void onCleared() {

            }
        });

        mPicasso.load(IconHandler.getUri(mPackageName))
                .priority(Picasso.Priority.HIGH)
                .into(LockAppIcon);

        return root;
    }

    private boolean beforeInflate() {
        if (mIntent == null) {
            return false;
        }

        mAction = mIntent.getAction();
        if (mAction == null) {
            return false;
        }

        if (!getPackageName().equals(mPackageName)) {
            Intent i = new Intent(this, AppLockService.class);
            if (mServiceState == ServiceState.NOT_BOUND) {
                mServiceState = ServiceState.BINDING;

                //bindService(i, mConnection, 0);
            }
        }
        mAppLockService = AppLockService.getSharedInstance();
        mPackageName = mIntent.getStringExtra(EXTRA_PACKAGENAME);
        mPattern = AppPreferences.getPattern(getApplicationContext());
        Log.i("CurrentPattern", "" + mPattern);

        mLayoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        mLayoutParams.screenOrientation = 1;

        Picasso.Builder builder = new Picasso.Builder(getApplicationContext());
        builder.addRequestHandler(new IconHandler(getApplicationContext()));
        mPicasso = builder.build();

        return true;
    }

    private void onViewShown() {

        mTimeViewShown = System.nanoTime();
        mViewState = ViewState.SHOWN;
        //mAnimShow = null;
    }

    private void showView() {
        if (mViewState == ViewState.HIDING || mViewState == ViewState.SHOWING) {
            //cancelAnimations();
        }

        if (mViewState != ViewState.HIDDEN) {
            //mWindowManager.removeView(mRootView);
        }

        beforeInflate();
        mRootView = inflateRootView();
        mWindowManager.addView(mRootView, mLayoutParams);
        //afterInflate();
        mViewState = ViewState.SHOWING;
        //showViewAnimate();
        onViewShown();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mServiceState != ServiceState.NOT_BOUND) {
            //unbindService(mConnection);
            mServiceState = ServiceState.NOT_BOUND;
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    private void finish(boolean unlocked) {
        if (!unlocked) {
            final Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }
        hideView();
    }

    private void hideView() {
        if (mViewState == ViewState.HIDING || mViewState == ViewState.HIDDEN) {
            onViewHidden();
            return;
        }
        if (mViewState == ViewState.SHOWING) {
            //cancelAnimations();
        }
        mViewState = ViewState.HIDING;
        onViewHidden();
    }

    private void onViewHidden() {

        if (mViewState != ViewState.HIDDEN) {
            mViewState = ViewState.HIDDEN;
            mWindowManager.removeView(mRootView);
        }

        stopSelf();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            /*case R.id.btn_unlock:
                mAppLockService.unlockApp(mPackageName);
                //mAppLockService.setLastPackageName(mPackageName);

                break;*/
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                finish(false);
                break;
        }
        return true;
    }
}
