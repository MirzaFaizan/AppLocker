package com.codecanyon.bestapplock.view;


import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.codecanyon.bestapplock.R;

import agency.tango.materialintroscreen.SlideFragment;

public class CustomSlide2 extends SlideFragment {

    boolean mCanMove = false;
    Button btn_grant_permission;
    private int PERMISSION_CODE = 23;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.custom_slide2, container, false);
        btn_grant_permission = (Button) view.findViewById(R.id.btn_grant_permission);

        btn_grant_permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getActivity().getPackageName()));
                startActivityForResult(intent, PERMISSION_CODE);
            }
        });
        return view;
    }

    @Override
    public int backgroundColor() {
        return R.color.colorPrimary;
    }

    @Override
    public int buttonsColor() {
        return R.color.colorAccent;
    }

    @Override
    public boolean canMoveFurther() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return android.provider.Settings.canDrawOverlays(getActivity());
        } else {
            return true;
        }
    }

    @Override
    public String cantMoveFurtherErrorMessage() {
        return "Grant overlay permission to move further";
    }
}
