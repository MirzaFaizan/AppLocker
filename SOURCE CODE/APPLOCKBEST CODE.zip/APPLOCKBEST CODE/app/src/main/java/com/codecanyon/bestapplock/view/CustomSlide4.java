package com.codecanyon.bestapplock.view;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.codecanyon.bestapplock.R;
import com.codecanyon.bestapplock.utils.AppPreferences;

import java.util.ArrayList;
import java.util.List;

import agency.tango.materialintroscreen.SlideFragment;

public class CustomSlide4 extends SlideFragment {

    boolean mCanMove = false;
    TextView txt_email_slide;
    Spinner spnr_question;
    List<String> questions;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.custom_slide4, container, false);
        txt_email_slide = (TextView) view.findViewById(R.id.txt_email_slide4);
        spnr_question = (Spinner) view.findViewById(R.id.spnr_question);
        questions = new ArrayList<String>();
        questions.add("Who was your childhood hero?");
        questions.add("Which is your favorite movie?");
        questions.add("What is the name of first pet?");
        questions.add("What is your city of birth?");
        questions.add("What is your favorite book?");
        questions.add("What is your favorite song?");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, questions);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnr_question.setAdapter(dataAdapter);

        spnr_question.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                AppPreferences.setSecurityQuestion(getActivity().getApplicationContext(), questions.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }

    @Override
    public int backgroundColor() {
        return R.color.colorPrimary;
    }

    @Override
    public int buttonsColor() {
        return R.color.colorAccent;
    }

    @Override
    public boolean canMoveFurther() {
        AppPreferences.setSecurityAnswer(getActivity().getApplicationContext(), txt_email_slide.getText().toString());
        return !txt_email_slide.getText().toString().equalsIgnoreCase("");
    }

    @Override
    public String cantMoveFurtherErrorMessage() {
        return "Please enter valid email address";
    }
}


