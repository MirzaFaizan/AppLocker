package com.codecanyon.bestapplock;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.codecanyon.bestapplock.adapter.AppAdapter;
import com.codecanyon.bestapplock.model.AppModel;
import com.codecanyon.bestapplock.services.AppLockService;
import com.codecanyon.bestapplock.utils.AppLoader;
import com.codecanyon.bestapplock.utils.AppPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.Set;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<AppModel>> {

    Toolbar toolbar;
    RecyclerView recyclerView;
    AppAdapter mAdapter;
    String mCurFilter;
    Set<String> LockedAppSet;
    private FirebaseAnalytics mFirebaseAnalytics;
    InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("App Lock");
        setSupportActionBar(toolbar);

        FirebaseApp.initializeApp(this);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        if (!AppPreferences.getAppIntro(this)) {
            Intent i = new Intent(getApplicationContext(), AppIntroActivity.class);
            startActivity(i);
        } else {
            if (AppPreferences.getPasscodeType(this).equalsIgnoreCase("0")) {
                Intent i = new Intent(getApplicationContext(), SetPasscodeActivity.class);
                startActivity(i);
            } else {
                Intent i = new Intent(getApplicationContext(), SetPatternActivity.class);
                startActivity(i);
            }
        }

        if (AppPreferences.getAppIntro(this)) {
            if (!isAccessibilitySettingsOn(this)) {
                Intent i = new Intent(getApplicationContext(), AllowAccessActivity.class);
                startActivity(i);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    Intent i = new Intent(getApplicationContext(), AllowAccessActivity.class);
                    startActivity(i);
                }
            }
        }

        SetUpViews();

        MobileAds.initialize(getApplicationContext(), getResources().getString(R.string.app_id));
        final AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("9C7EDF9236FE42147D1F7317080B1055").build();
        mAdView.loadAd(adRequest);
        mAdView.setVisibility(View.GONE);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

        LockedAppSet = AppPreferences.getAllLockedApps(this);
        if (!LockedAppSet.contains("com.android.vending")) {
            AppPreferences.addLockApp(this, "com.android.vending");
        } else if (!LockedAppSet.contains("com.android.settings")) {
            AppPreferences.addLockApp(this, "com.android.settings");
        }
        LockedAppSet = AppPreferences.getAllLockedApps(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        mAdapter = new AppAdapter(this, null, LockedAppSet, new AppAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(AppModel item, View itemView, int position) {
                mAdapter.toggleSelection(position);
            }
        });


        recyclerView.setAdapter(new AlphaInAnimationAdapter(mAdapter));

        getLoaderManager().initLoader(0, null, this);
        requestNewInterstitial();
    }

    private void requestNewInterstitial() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.int_ad_unit_id));
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice("9C7EDF9236FE42147D1F7317080B1055")
                .build();
        mInterstitialAd.loadAd(adRequest);
    }

    private void SetUpViews() {
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
    }

    @Override
    public Loader<ArrayList<AppModel>> onCreateLoader(int id, Bundle args) {
        return new AppLoader(this);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<AppModel>> loader, ArrayList<AppModel> data) {
        mAdapter.swap(data);
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<AppModel>> loader) {
        mAdapter.swap(null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(search);
        search(searchView);
        return true;
    }

    private void search(final SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mCurFilter = !TextUtils.isEmpty(newText) ? newText : "";
                mAdapter.getFilter().filter(mCurFilter);
                return true;
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                if (!TextUtils.isEmpty(searchView.getQuery())) {
                    searchView.setQuery("", true);
                }
                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings:
                Intent mIntentSettings = new Intent(this, SettingActivity.class);
                startActivity(mIntentSettings);
                if (mInterstitialAd != null) {
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        requestNewInterstitial();
                    }
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean isAccessibilitySettingsOn(Context mContext) {
        int accessibilityEnabled = 0;
        final String service = getPackageName() + "/" + AppLockService.class.getCanonicalName();
        try {
            accessibilityEnabled = Settings.Secure.getInt(
                    mContext.getApplicationContext().getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED);
            Log.v("accessibility", "accessibilityEnabled = " + accessibilityEnabled);
        } catch (Settings.SettingNotFoundException e) {
            Log.e("accessibility", "Error finding setting, default accessibility to not found: "
                    + e.getMessage());
        }
        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');

        if (accessibilityEnabled == 1) {
            Log.v("accessibility", "***ACCESSIBILITY IS ENABLED*** -----------------");
            String settingValue = Settings.Secure.getString(
                    mContext.getApplicationContext().getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    String accessibilityService = mStringColonSplitter.next();

                    Log.v("accessibility", "-------------- > accessibilityService :: " + accessibilityService + " " + service);
                    if (accessibilityService.equalsIgnoreCase(service)) {
                        Log.v("accessibility", "We've found the correct setting - accessibility is switched on!");
                        return true;
                    }
                }
            }
        } else {
            Log.v("accessibility", "***ACCESSIBILITY IS DISABLED***");
        }

        return false;
    }
}
