package com.codecanyon.bestapplock.utils;


import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public class AppPreferences {

    public static void addLockApp(Context context, String packagename) {
        Set<String> LockedAppSet = getAllLockedApps(context);
        LockedAppSet.add(packagename);
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APPLOCK_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.clear();
        editor.putStringSet("LockedApp", LockedAppSet);
        editor.apply();
    }

    public static void removeLockApp(Context context, String packagename) {
        Set<String> LockedAppSet = getAllLockedApps(context);
        LockedAppSet.remove(packagename);
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APPLOCK_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.clear();
        editor.putStringSet("LockedApp", LockedAppSet);
        editor.apply();
    }

    public static Set<String> getAllLockedApps(Context context) {

        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APPLOCK_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getStringSet("LockedApp", new HashSet<String>());
    }

    public static void setPasscode(Context context, String Passcode) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putString("Passcode", Passcode);
        editor.apply();
    }

    public static String getPasscode(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getString("Passcode", null);
    }

    public static String getPasscodeType(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getString("PasscodeType", "0");
    }

    public static void setPasscodeType(Context context, String PasscodeType) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putString("PasscodeType", PasscodeType);
        editor.apply();
    }

    public static void setPattern(Context context, String Pattern) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putString("Pattern", Pattern);
        editor.apply();
    }

    public static String getPattern(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getString("Pattern", null);
    }

    public static void setAppIntro(Context context, boolean value) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putBoolean("AppIntro", value);
        editor.apply();
    }

    public static boolean getAppIntro(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getBoolean("AppIntro", false);
    }

    public static void setPasscodeSetup(Context context, boolean value) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putBoolean("PasscodeSetup", value);
        editor.apply();
    }

    public static boolean getPasscodeSetup(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getBoolean("PasscodeSetup", false);
    }

    public static String getSecurityAnswer(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getString("SecurityAnswer", null);
    }

    public static void setSecurityAnswer(Context context, String SecurityAnswer) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putString("SecurityAnswer", SecurityAnswer);
        editor.apply();
    }

    public static String getSecurityQuestion(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE);
        return preferences.getString("SecurityQuestion", null);
    }

    public static void setSecurityQuestion(Context context, String SecurityQuestion) {
        SharedPreferences.Editor editor = context.getSharedPreferences(AppConstant.APP_PREFERENCE,
                Context.MODE_PRIVATE).edit();
        editor.putString("SecurityQuestion", SecurityQuestion);
        editor.apply();
    }
}
