package com.codecanyon.bestapplock;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.codecanyon.bestapplock.utils.AppPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.List;

public class SetPatternActivity extends AppCompatActivity {

    String Pattern, CurrentPattern;
    TextView TxtEnterPasscode, TxtForgetPasscode;
    PatternLockView mPatternLockView;
    Boolean mChangePattern = false;
    Boolean mForget = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pattern);

        mPatternLockView = (PatternLockView) findViewById(R.id.pattern_lock_view);
        TxtEnterPasscode = (TextView) findViewById(R.id.TxtEnterPasscode);
        TxtForgetPasscode = (TextView) findViewById(R.id.TxtForgetPasscode);

        Pattern = AppPreferences.getPattern(getApplicationContext());

        mChangePattern = this.getIntent().hasExtra("ChangePattern");
        mForget = this.getIntent().hasExtra("Forget");

        if (mChangePattern) {
            Pattern = null;
        }

        if (mForget || mChangePattern || Pattern == null) {
            TxtForgetPasscode.setVisibility(View.GONE);
        }

        TxtForgetPasscode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mIntentSettings = new Intent(getApplicationContext(), ForgetPasswordActivity.class);
                startActivity(mIntentSettings);
                finish();
            }
        });


        MobileAds.initialize(getApplicationContext(), getResources().getString(R.string.app_id));
        final AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("9C7EDF9236FE42147D1F7317080B1055").build();
        mAdView.loadAd(adRequest);
        mAdView.setVisibility(View.GONE);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });


        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(final List<PatternLockView.Dot> pattern) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {
                        CurrentPattern = PatternLockUtils.patternToString(mPatternLockView, pattern);
                        if (Pattern == null) {
                            Pattern = CurrentPattern;
                            TxtEnterPasscode.setText("Confirm Pattern");
                            mPatternLockView.clearPattern();
                        } else {
                            if (Pattern.equalsIgnoreCase(CurrentPattern)) {
                                Log.i("CurrentPattern", "" + CurrentPattern);
                                AppPreferences.setPattern(getApplicationContext(), CurrentPattern);
                                AppPreferences.setPasscode(getApplicationContext(), null);
                                AppPreferences.setPasscodeType(getApplicationContext(), "1");
                                AppPreferences.setPasscodeSetup(getApplicationContext(), true);
                                mPatternLockView.clearPattern();
                                if (mChangePattern) {
                                    finish();
                                } else {
                                    finish();
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Pattern dose not match.", Toast.LENGTH_SHORT).show();
                                mPatternLockView.setViewMode(PatternLockView.PatternViewMode.WRONG);
                            }
                        }
                    }
                }, 300);
            }

            @Override
            public void onCleared() {

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mChangePattern && !mForget) {
            finish();
        } else {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }
    }
}
