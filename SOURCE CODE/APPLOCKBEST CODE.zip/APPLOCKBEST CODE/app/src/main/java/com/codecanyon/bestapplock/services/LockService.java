package com.codecanyon.bestapplock.services;


import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.codecanyon.bestapplock.R;
import com.codecanyon.bestapplock.utils.AppPreferences;
import com.codecanyon.bestapplock.utils.IconHandler;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.picasso.Picasso;

public class LockService extends Service implements View.OnClickListener,
        View.OnKeyListener {

    //Flags
    private ViewState mViewState = ViewState.HIDDEN;

    private enum ViewState {SHOWING, SHOWN, HIDING, HIDDEN}

    private ServiceState mServiceState = ServiceState.NOT_BOUND;

    private enum ServiceState {NOT_BOUND, BINDING, BOUND, UNBINDING}

    //Others
    private AppLockService mAppLockService;
    private Intent mIntent;
    private String mAction;
    private String mPackageName;
    private long mTimeViewShown;

    //Window views
    private WindowManager.LayoutParams mLayoutParams;
    private WindowManager mWindowManager;

    //Views
    private View mRootView;

    TextView TxtPasscode1, TxtPasscode2, TxtPasscode3, TxtPasscode4,
            TxtPasscode5, TxtPasscode6, TxtPasscode7, TxtPasscode8,
            TxtPasscode9, TxtPasscode0, TxtEnterPasscode;
    RelativeLayout BtnPasscode1, BtnPasscode2, BtnPasscode3, BtnPasscode4,
            BtnPasscode5, BtnPasscode6, BtnPasscode7, BtnPasscode8,
            BtnPasscode9, BtnPasscode0, LayoutPasscode;
    Typeface UnlockFontThin, UnlockMedium, UnlockLight;

    ImageView PassDot1, PassDot2, PassDot3, PassDot4, LockAppIcon;

    String Passcode, EnterPasscode;
    Boolean vibrate = false;

    private Picasso mPicasso;

    //Actions
    private static final String CLASSNAME = LockService.class.getName();
    private static final String ACTION_HIDE = CLASSNAME + ".action.hide";
    public static final String ACTION_COMPARE = CLASSNAME + ".action.compare";
    private static final String ACTION_NOTIFY_PACKAGE_CHANGED = CLASSNAME
            + ".action.notify_package_changed";

    public static final String EXTRA_PACKAGENAME = CLASSNAME;

    private final ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName cn, IBinder binder) {


            mServiceState = ServiceState.BOUND;
        }

        @Override
        public void onServiceDisconnected(ComponentName cn) {
            mServiceState = ServiceState.UNBINDING;
        }
    };

    public static Intent getLockIntent(Context c, String packageName) {
        Intent i = new Intent(c, LockService.class);
        i.setAction(ACTION_COMPARE);
        i.putExtra(EXTRA_PACKAGENAME, packageName);
        return i;
    }

    public static void hide(Context c) {
        Intent i = new Intent(c, LockService.class);
        i.setAction(ACTION_HIDE);
        c.startService(i);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }

        if (ACTION_HIDE.equals(intent.getAction())) {
            finish(true);
            return START_NOT_STICKY;
        }

        if (ACTION_NOTIFY_PACKAGE_CHANGED.equals(intent.getAction())) {
            String newPackageName = intent.getStringExtra(EXTRA_PACKAGENAME);
            if (newPackageName == null
                    || !getPackageName().equals(newPackageName)) {
                finish(true);
                return START_NOT_STICKY;
            }
        } else {
            mIntent = intent;
            showView();
        }
        return START_NOT_STICKY;
    }


    private View inflateRootView() {
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater li = LayoutInflater.from(this);
        View root = (View) li.inflate(R.layout.activity_lock, null);


        root.setOnKeyListener(this);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);

        BtnPasscode1 = (RelativeLayout) root.findViewById(R.id.BtnPasscode1);
        BtnPasscode2 = (RelativeLayout) root.findViewById(R.id.BtnPasscode2);
        BtnPasscode3 = (RelativeLayout) root.findViewById(R.id.BtnPasscode3);
        BtnPasscode4 = (RelativeLayout) root.findViewById(R.id.BtnPasscode4);
        BtnPasscode5 = (RelativeLayout) root.findViewById(R.id.BtnPasscode5);
        BtnPasscode6 = (RelativeLayout) root.findViewById(R.id.BtnPasscode6);
        BtnPasscode7 = (RelativeLayout) root.findViewById(R.id.BtnPasscode7);
        BtnPasscode8 = (RelativeLayout) root.findViewById(R.id.BtnPasscode8);
        BtnPasscode9 = (RelativeLayout) root.findViewById(R.id.BtnPasscode9);
        BtnPasscode0 = (RelativeLayout) root.findViewById(R.id.BtnPasscode0);
        LayoutPasscode = (RelativeLayout) root.findViewById(R.id.LayoutPasscode);

        TxtPasscode1 = (TextView) root.findViewById(R.id.TxtPasscode1);
        TxtPasscode2 = (TextView) root.findViewById(R.id.TxtPasscode2);
        TxtPasscode3 = (TextView) root.findViewById(R.id.TxtPasscode3);
        TxtPasscode4 = (TextView) root.findViewById(R.id.TxtPasscode4);
        TxtPasscode5 = (TextView) root.findViewById(R.id.TxtPasscode5);
        TxtPasscode6 = (TextView) root.findViewById(R.id.TxtPasscode6);
        TxtPasscode7 = (TextView) root.findViewById(R.id.TxtPasscode7);
        TxtPasscode8 = (TextView) root.findViewById(R.id.TxtPasscode8);
        TxtPasscode9 = (TextView) root.findViewById(R.id.TxtPasscode9);
        TxtPasscode0 = (TextView) root.findViewById(R.id.TxtPasscode0);

        TxtEnterPasscode = (TextView) root.findViewById(R.id.TxtEnterPasscode);

        PassDot1 = (ImageView) root.findViewById(R.id.PassDot1);
        PassDot2 = (ImageView) root.findViewById(R.id.PassDot2);
        PassDot3 = (ImageView) root.findViewById(R.id.PassDot3);
        PassDot4 = (ImageView) root.findViewById(R.id.PassDot4);

        LockAppIcon = (ImageView) root.findViewById(R.id.LockAppIcon);

        MobileAds.initialize(getApplicationContext(), getResources().getString(R.string.app_id));
        final AdView mAdView = (AdView) root.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("9C7EDF9236FE42147D1F7317080B1055").build();
        mAdView.loadAd(adRequest);
        mAdView.setVisibility(View.GONE);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });


        TxtPasscode1.setTypeface(UnlockFontThin);
        TxtPasscode2.setTypeface(UnlockFontThin);
        TxtPasscode3.setTypeface(UnlockFontThin);
        TxtPasscode4.setTypeface(UnlockFontThin);
        TxtPasscode5.setTypeface(UnlockFontThin);
        TxtPasscode6.setTypeface(UnlockFontThin);
        TxtPasscode7.setTypeface(UnlockFontThin);
        TxtPasscode8.setTypeface(UnlockFontThin);
        TxtPasscode9.setTypeface(UnlockFontThin);
        TxtPasscode0.setTypeface(UnlockFontThin);
        TxtEnterPasscode.setTypeface(UnlockLight);

        mPicasso.load(IconHandler.getUri(mPackageName))
                .priority(Picasso.Priority.HIGH)
                .into(LockAppIcon);

        BtnPasscode1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "1";
                PasscodeEntered(EnterPasscode);

            }

        });

        BtnPasscode2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "2";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "3";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "4";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "5";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "6";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "7";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "8";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode9.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "9";
                PasscodeEntered(EnterPasscode);
            }
        });

        BtnPasscode0.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EnterPasscode = EnterPasscode + "0";
                PasscodeEntered(EnterPasscode);
            }
        });

        //mButtonUnlock = (Button) root.findViewById(R.id.btn_unlock);

        //mButtonUnlock.setOnClickListener(this);

        return root;
    }

    public void PasscodeEntered(final String EPass) {
        // TODO Auto-generated method stub
        int passdot = EPass.length();
        if (passdot == 1) {

            PassDot1.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
        } else if (passdot == 2) {
            PassDot1.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot2.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));

        } else if (passdot == 3) {
            PassDot1.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot2.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot3.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));

        } else if (passdot == 4) {
            PassDot1.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot2.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot3.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));
            PassDot4.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),
                    R.drawable.pass_fill));

        }
        if (EPass.length() >= 4) {
            EnableControle(false);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    if (EPass.equalsIgnoreCase(Passcode)) {
                        //if (getBoolSound(mContext)) {
                        //    play(mContext, R.raw.unlock);
                        //}
                        mAppLockService.unlockApp(mPackageName);
                        finish(true);
                        /*stopService(new Intent(getApplicationContext(),
                                LockService.class));*/
                        //SavePreferences("LockState", "OPEN");
                    } else {

                        Animation shake = AnimationUtils.loadAnimation(
                                getApplicationContext(), R.anim.shake);
                        LayoutPasscode.startAnimation(shake);
                        // txt_enter_password.setText("Try again");
                        // txt_delete.setText("Cancel");
                        /*if (getBoolVibration(mContext)) {
                            Vibrator v = (Vibrator) mContext
                                    .getApplicationContext().getSystemService(
                                            Context.VIBRATOR_SERVICE);
                            // Vibrate for 500 milliseconds
                            v.vibrate(500);
                        }*/
                        shake.setAnimationListener(new Animation.AnimationListener() {

                            @Override
                            public void onAnimationStart(Animation animation) {
                                // TODO Auto-generated method stub
                                EnterPasscode = "";
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {
                                // TODO Auto-generated method stub

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                // TODO Auto-generated method stub
                                EnableControle(true);
                                PassDot1.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pass_border));
                                PassDot2.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pass_border));
                                PassDot3.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pass_border));
                                PassDot4.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pass_border));
                            }
                        });

                    }
                }
            }, 300);

        }
    }

    private void EnableControle(boolean value) {
        BtnPasscode1.setClickable(value);
        BtnPasscode2.setClickable(value);
        BtnPasscode3.setClickable(value);
        BtnPasscode4.setClickable(value);
        BtnPasscode5.setClickable(value);
        BtnPasscode6.setClickable(value);
        BtnPasscode7.setClickable(value);
        BtnPasscode8.setClickable(value);
        BtnPasscode9.setClickable(value);
        BtnPasscode0.setClickable(value);
    }

    private boolean beforeInflate() {
        if (mIntent == null) {
            return false;
        }

        mAction = mIntent.getAction();
        if (mAction == null) {
            return false;
        }

        if (!getPackageName().equals(mPackageName)) {
            Intent i = new Intent(this, AppLockService.class);
            if (mServiceState == ServiceState.NOT_BOUND) {
                mServiceState = ServiceState.BINDING;

                //bindService(i, mConnection, 0);
            }
        }
        mAppLockService = AppLockService.getSharedInstance();
        mPackageName = mIntent.getStringExtra(EXTRA_PACKAGENAME);

        UnlockFontThin = Typeface.createFromAsset(getAssets(),
                "Roboto-Thin.ttf");
        UnlockMedium = Typeface.createFromAsset(getAssets(),
                "Roboto-Medium.ttf");
        UnlockLight = Typeface.createFromAsset(getAssets(),
                "Roboto-Light.ttf");
        Passcode = AppPreferences.getPasscode(getApplicationContext());
        Log.i("CurrentPasscode", "" + Passcode);
        EnterPasscode = "";

        mLayoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        mLayoutParams.screenOrientation = 1;

        Picasso.Builder builder = new Picasso.Builder(getApplicationContext());
        builder.addRequestHandler(new IconHandler(getApplicationContext()));
        mPicasso = builder.build();

        return true;
    }

    private void onViewShown() {

        mTimeViewShown = System.nanoTime();
        mViewState = ViewState.SHOWN;
        //mAnimShow = null;
    }

    private void showView() {
        if (mViewState == ViewState.HIDING || mViewState == ViewState.SHOWING) {
            //cancelAnimations();
        }

        if (mViewState != ViewState.HIDDEN) {
            //mWindowManager.removeView(mRootView);
        }

        beforeInflate();
        mRootView = inflateRootView();
        mWindowManager.addView(mRootView, mLayoutParams);
        //afterInflate();
        mViewState = ViewState.SHOWING;
        //showViewAnimate();
        onViewShown();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mServiceState != ServiceState.NOT_BOUND) {
            //unbindService(mConnection);
            mServiceState = ServiceState.NOT_BOUND;
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    private void finish(boolean unlocked) {
        if (!unlocked) {
            final Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }
        hideView();
    }

    private void hideView() {
        if (mViewState == ViewState.HIDING || mViewState == ViewState.HIDDEN) {
            onViewHidden();
            return;
        }
        if (mViewState == ViewState.SHOWING) {
            //cancelAnimations();
        }
        mViewState = ViewState.HIDING;
        onViewHidden();
    }

    private void onViewHidden() {

        if (mViewState != ViewState.HIDDEN) {
            mViewState = ViewState.HIDDEN;
            mWindowManager.removeView(mRootView);
        }

        stopSelf();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            /*case R.id.btn_unlock:
                mAppLockService.unlockApp(mPackageName);
                //mAppLockService.setLastPackageName(mPackageName);

                break;*/
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                finish(false);
                return true;
        }
        return true;
    }


}
