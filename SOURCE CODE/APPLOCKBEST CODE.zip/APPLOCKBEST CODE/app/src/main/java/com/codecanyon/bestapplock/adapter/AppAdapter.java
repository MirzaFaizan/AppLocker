package com.codecanyon.bestapplock.adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.codecanyon.bestapplock.R;
import com.codecanyon.bestapplock.model.AppModel;
import com.codecanyon.bestapplock.utils.AppPreferences;
import com.codecanyon.bestapplock.utils.IconHandler;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Set;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.MyViewHolder> implements Filterable {

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    mFilterAppList = mAppList;
                } else {

                    ArrayList<AppModel> filteredList = new ArrayList<>();

                    for (AppModel mAppModel : mAppList) {

                        if (mAppModel.getLabel().toLowerCase().contains(charString)) {

                            filteredList.add(mAppModel);
                        }
                    }

                    mFilterAppList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilterAppList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilterAppList = (ArrayList<AppModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }


    public interface OnItemClickListener {
        void onItemClick(AppModel item, View itemView, int position);
    }

    private ArrayList<AppModel> mAppList;
    private ArrayList<AppModel> mFilterAppList;
    private final OnItemClickListener listener;
    private Context mContext;
    Set<String> LockedAppSet;
    private Picasso mPicasso;

    public void swap(ArrayList<AppModel> datas) {
        if (mAppList != null)
            mAppList.clear();
        mAppList = datas;
        mFilterAppList = datas;
        notifyDataSetChanged();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView item_app_list_text;
        public ImageView item_app_list_image;
        public SwitchCompat item_app_list_switch;

        public MyViewHolder(View view) {
            super(view);
            item_app_list_text = (TextView) view.findViewById(R.id.item_app_list_text);
            item_app_list_image = (ImageView) view.findViewById(R.id.item_app_list_image);
            item_app_list_switch = (SwitchCompat) view.findViewById(R.id.item_app_list_switch);
        }

        public void bind(final AppModel appmodel, final OnItemClickListener listener, final int position) {
            item_app_list_text.setText(appmodel.getLabel());
            mPicasso.load(IconHandler.getUri(appmodel.getApplicationPackageName()))
                    .priority(Picasso.Priority.HIGH)
                    .into(item_app_list_image);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(appmodel, itemView, position);
                }
            });

        }
    }

    public AppAdapter(Context mContext, ArrayList<AppModel> contacts, Set<String> LockedAppSet, OnItemClickListener listener) {
        this.mAppList = contacts;
        this.mFilterAppList = contacts;
        this.listener = listener;
        this.mContext = mContext;
        this.LockedAppSet = LockedAppSet;
        Picasso.Builder builder = new Picasso.Builder(mContext);
        builder.addRequestHandler(new IconHandler(mContext));
        mPicasso = builder.build();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.item_app_list_switch.setChecked(LockedAppSet.contains(mFilterAppList.get(position).getApplicationPackageName()));
        holder.bind(mFilterAppList.get(position), listener, position);
    }

    @Override
    public int getItemCount() {
        return (mFilterAppList == null) ? 0 : mFilterAppList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public void toggleSelection(int position) {
        String mPackageName = mFilterAppList.get(position).getApplicationPackageName();
        Lock(LockedAppSet.contains(mPackageName), mPackageName);
    }

    private void Lock(boolean value, String mPackageName) {
        if (value) {
            LockedAppSet.remove(mPackageName);
            AppPreferences.removeLockApp(mContext, mPackageName);
        } else {
            LockedAppSet.add(mPackageName);
            AppPreferences.addLockApp(mContext, mPackageName);
        }
        notifyDataSetChanged();
    }
}
