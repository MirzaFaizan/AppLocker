package com.codecanyon.bestapplock.utils;


public class AppConstant {

    public static final String APPLOCK_PREFERENCE = "applockpref";
    public static final String APP_PREFERENCE = "apppref";
}
