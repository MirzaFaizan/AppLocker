package com.codecanyon.bestapplock;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.preference.ListPreference;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.util.Log;

import com.codecanyon.bestapplock.utils.AppPreferences;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;


public class Setting extends PreferenceFragmentCompat {

    public static final String FRAGMENT_TAG = "my_lockscreen_preference_fragment";

    InterstitialAd mInterstitialAd;
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.setting, rootKey);

        Preference mPrefChangePasscode = findPreference("changepasscode");
        mPrefChangePasscode.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                if (AppPreferences.getPasscodeType(getActivity().getApplicationContext()).equalsIgnoreCase("0")) {
                    Intent mIntentSettings = new Intent(getActivity(), SetPasscodeActivity.class);
                    mIntentSettings.putExtra("ChangePasscode", true);
                    startActivity(mIntentSettings);
                    if (mInterstitialAd != null) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                            requestNewInterstitial();
                        }
                    }
                } else {
                    Intent mIntentSettings = new Intent(getActivity(), SetPatternActivity.class);
                    mIntentSettings.putExtra("ChangePattern", true);
                    startActivity(mIntentSettings);
                    if (mInterstitialAd != null) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                            requestNewInterstitial();
                        }
                    }
                }
                return true;
            }
        });
        requestNewInterstitial();

        ListPreference mPrefPasscodeType = (ListPreference) findPreference("passcodetype");
        if (mPrefPasscodeType.getValue() == null) {
            mPrefPasscodeType.setValueIndex(0);
        } else {
            if (AppPreferences.getPasscodeType(getActivity().getApplicationContext()).equalsIgnoreCase("0")) {
                mPrefPasscodeType.setValueIndex(0);
            } else {
                mPrefPasscodeType.setValueIndex(1);
            }
        }

        Preference mPrefRatenow = findPreference("ratenow");

        mPrefRatenow.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri
                            .parse("market://details?id="
                                    + getActivity().getPackageName())));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id="
                                    + getActivity().getPackageName())));
                }
                return true;
            }
        });

        mPrefPasscodeType.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Log.i("NEWVALUE", "" + newValue);
                if (newValue.toString().equalsIgnoreCase("0")) {
                    Intent mIntentSettings = new Intent(getActivity(), SetPasscodeActivity.class);
                    mIntentSettings.putExtra("ChangePasscode", true);
                    startActivity(mIntentSettings);
                    if (mInterstitialAd != null) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                            requestNewInterstitial();
                        }
                    }
                } else {
                    Intent mIntentSettings = new Intent(getActivity(), SetPatternActivity.class);
                    mIntentSettings.putExtra("ChangePattern", true);
                    startActivity(mIntentSettings);
                    if (mInterstitialAd != null) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                            requestNewInterstitial();
                        }
                    }
                }
                return true;
            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.int_ad_unit_id));
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice("9C7EDF9236FE42147D1F7317080B1055")
                .build();
        mInterstitialAd.loadAd(adRequest);
    }

    @Override
    public void onResume() {
        super.onResume();
        ListPreference mPrefPasscodeType = (ListPreference) findPreference("passcodetype");
        if (mPrefPasscodeType.getValue() == null) {
            mPrefPasscodeType.setValueIndex(0);
        } else {
            if (AppPreferences.getPasscodeType(getActivity().getApplicationContext()).equalsIgnoreCase("0")) {
                mPrefPasscodeType.setValueIndex(0);
            } else {
                mPrefPasscodeType.setValueIndex(1);
            }
        }
    }
}
