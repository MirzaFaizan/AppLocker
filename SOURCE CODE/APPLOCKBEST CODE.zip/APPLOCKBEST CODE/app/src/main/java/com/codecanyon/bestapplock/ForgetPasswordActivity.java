package com.codecanyon.bestapplock;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.codecanyon.bestapplock.utils.AppPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class ForgetPasswordActivity extends AppCompatActivity {

    TextView txt_security_question;
    EditText txtbx_security_answer;
    Button btn_security_done;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        txt_security_question = (TextView) findViewById(R.id.txt_security_question);
        txtbx_security_answer = (EditText) findViewById(R.id.txtbx_security_answer);
        btn_security_done = (Button) findViewById(R.id.btn_security_done);

        txt_security_question.setText(AppPreferences.getSecurityQuestion(getApplicationContext()));

        MobileAds.initialize(getApplicationContext(), getResources().getString(R.string.app_id));
        final AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("9C7EDF9236FE42147D1F7317080B1055").build();
        mAdView.loadAd(adRequest);
        mAdView.setVisibility(View.GONE);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });



        btn_security_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AppPreferences.getSecurityAnswer(getApplicationContext()).equalsIgnoreCase(txtbx_security_answer.getText().toString())) {
                    if (AppPreferences.getPasscodeType(getApplicationContext()).equalsIgnoreCase("0")) {
                        Intent mIntentSettings = new Intent(getApplicationContext(), SetPasscodeActivity.class);
                        mIntentSettings.putExtra("ChangePasscode", true);
                        mIntentSettings.putExtra("Forget", true);
                        startActivity(mIntentSettings);
                        finish();
                    } else {
                        Intent mIntentSettings = new Intent(getApplicationContext(), SetPatternActivity.class);
                        mIntentSettings.putExtra("ChangePattern", true);
                        mIntentSettings.putExtra("Forget", true);
                        startActivity(mIntentSettings);
                        finish();
                    }
                } else {
                    txtbx_security_answer.setError("Answer not match");
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }
}
