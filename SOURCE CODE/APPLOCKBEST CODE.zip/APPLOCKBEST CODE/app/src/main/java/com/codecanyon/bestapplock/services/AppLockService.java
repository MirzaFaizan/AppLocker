package com.codecanyon.bestapplock.services;


import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import com.codecanyon.bestapplock.utils.AppPreferences;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class AppLockService extends AccessibilityService {

    String mCurrentPackage = "";
    Set<String> LockedAppSet;
    private Map<String, Boolean> mLockedPackages;
    private static AppLockService sSharedInstance;
    String mLastPackageName = "";
    private BroadcastReceiver mScreenReceiver;

    @Override
    protected void onServiceConnected() {
        //LockedAppSet = AppPreferences.getAllLockedApps(getApplicationContext());
        sSharedInstance = this;
        Log.i("mCurrentPackage", "Service connected");
        mScreenReceiver = new ScreenReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mScreenReceiver, filter);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        sSharedInstance = null;
        return super.onUnbind(intent);
    }

    public static AppLockService getSharedInstance() {
        return sSharedInstance;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

        mCurrentPackage = event.getPackageName().toString();
        Log.i("mCurrentPackage", "" + mCurrentPackage);
        Log.i("mCurrentPackage", "" + event.getClassName());
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (!mCurrentPackage.equalsIgnoreCase(mLastPackageName) &&
                    !mCurrentPackage.equalsIgnoreCase(getPackageName()) &&
                    !mCurrentPackage.equalsIgnoreCase("com.android.systemui") && AppPreferences.getPasscodeSetup(this)) {
                LockedAppSet = AppPreferences.getAllLockedApps(getApplicationContext());
                mLockedPackages = new HashMap<>();
                for (String s : LockedAppSet) {
                    mLockedPackages.put(s, true);
                }
                mLastPackageName = mCurrentPackage;
                if (mLockedPackages.containsKey(mCurrentPackage)) {
                    if (mLockedPackages.get(mCurrentPackage)) {
                        Log.i("mCurrentPackage", "" + mCurrentPackage + " is locked " + AppPreferences.getPasscodeType(this));
                        if (AppPreferences.getPasscodeType(this) == null || AppPreferences.getPasscodeType(this).equalsIgnoreCase("0")) {
                            Intent intent = LockService.getLockIntent(this, mCurrentPackage);
                            intent.setAction(LockService.ACTION_COMPARE);
                            intent.putExtra(LockService.EXTRA_PACKAGENAME, mCurrentPackage);
                            startService(intent);
                        } else {
                            Intent intent = LockServicePattern.getLockIntent(this, mCurrentPackage);
                            intent.setAction(LockServicePattern.ACTION_COMPARE);
                            intent.putExtra(LockServicePattern.EXTRA_PACKAGENAME, mCurrentPackage);
                            startService(intent);
                        }
                    }
                }
            }
        }
    }

    public void unlockApp(String packageName) {
        if (mLockedPackages.containsKey(packageName)) {
            mLockedPackages.put(packageName, false);
        }
    }

    public void setLastPackageName(String packageName) {
        mLastPackageName = packageName;
    }

    void lockApp(String packageName) {
        if (mLockedPackages.containsKey(packageName)) {
            mLockedPackages.put(packageName, true);
        }
    }

    @Override
    public void onInterrupt() {
        if (mScreenReceiver != null)
            unregisterReceiver(mScreenReceiver);
    }

    private final class ScreenReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                Log.i("Service", "Screen ON");
                // Trigger package again
                mLastPackageName = "";
                //startAlarm(AppLockService.this);
            }
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                Log.i("Service", "Screen OFF");
                //stopAlarm(AppLockService.this);
                //if (mRelockScreenOff) {
                //   lockAll();
                // }
                if (AppPreferences.getPasscodeType(context) == null || AppPreferences.getPasscodeType(context).equalsIgnoreCase("0")) {
                    LockService.hide(context);
                } else {
                    LockServicePattern.hide(context);
                }
            }
        }
    }
}
